import React from 'react';

const withUser = (WrappedComponent) => {
  const user = {
    name: 'Vibhor Raut',
    email: 'vibhorgraut@gmail.com'
  };

  return (props) => {
    return <WrappedComponent user={user} {...props} />;
  };
};

export default withUser;