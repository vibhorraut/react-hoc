import React from 'react';
// import { Redirect } from 'react-router-dom';
import { Navigate } from 'react-router-dom';

const withAuthentication = (WrappedComponent) => {
  return class extends React.Component {
    isAuthenticated = () => {
      // Add our authentication logic here 
      return !!localStorage.getItem('authToken');
    };

    render() {
    //   if (!this.isAuthenticated()) {
    //     return <Redirect to="/login" />;
    //   }
    if (!this.isAuthenticated()) {
        return <Navigate to="/login" />;
      }

      return <WrappedComponent {...this.props} />;
    }
  };
};

export default withAuthentication;