// import React from 'react';
// // import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import LoginPage from './components/LoginPage';
// import Dashboard from './components/Dashboard';
// import withAuthentication from './hoc/withAuthentication';

// const AuthenticatedDashboard = withAuthentication(Dashboard);

// const App = () => {
//   return (
//     // <Router>
//     //   <Switch>
//     //     <Route path="/login" component={LoginPage} />
//     //     <Route path="/dashboard" component={AuthenticatedDashboard} />
//     //   </Switch>
//     // </Router>
//     <Router>
//     <Routes>
//       <Route path="/login" element={<LoginPage />} />
//       <Route path="/dashboard" element={<AuthenticatedDashboard />} />
//     </Routes>
//   </Router>
//   );
// };

// export default App;

// src/App.js
import React from 'react';
import withUser from './hoc/withUser';
import UserComponent from './components/UserComponent';

const EnhancedUserComponent = withUser(UserComponent);

const App = () => {
  return (
    <div>
      <EnhancedUserComponent />
    </div>
  );
};

export default App;