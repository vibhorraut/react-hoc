import React from 'react';

const LoginPage = () => {
  const handleLogin = () => {
    // I will perform login logic and set auth token
    localStorage.setItem('authToken', 'your-auth-token');
    window.location.href = '/dashboard';
  };

  return (
    <div>
      <h2>Login Page</h2>
      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default LoginPage;